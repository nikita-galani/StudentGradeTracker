package model;

public class Student {

	private int rollno;
	private String section ,name,grade;
	private double phy,maths,chem,eng,total,percentage;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public double getPhy() {
		return phy;
	}
	public void setPhy(double phy) {
		this.phy = phy;
	}
	public double getMaths() {
		return maths;
	}
	public void setMaths(double maths) {
		this.maths = maths;
	}
	public double getChem() {
		return chem;
	}
	public void setChem(double chem) {
		this.chem = chem;
	}
	public double getEng() {
		return eng;
	}
	public void setEng(double eng) {
		this.eng = eng;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", section=" + section + ", name=" + name + ", grade=" + grade + ", phy="
				+ phy + ", maths=" + maths + ", chem=" + chem + ", eng=" + eng + ", total=" + total + ", percentage="
				+ percentage + "]";
	}

	public Student(int rollno, String section, String name, String grade, double phy, double maths, double chem,
			double eng, double total, double percentage) {
		super();
		this.rollno = rollno;
		this.section = section;
		this.name = name;
		this.grade = grade;
		this.phy = phy;
		this.maths = maths;
		this.chem = chem;
		this.eng = eng;
		this.total = total;
		this.percentage = percentage;
	}
	
	
}
