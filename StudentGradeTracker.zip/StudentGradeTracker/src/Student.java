import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Student extends JFrame implements ActionListener{

	Container cp;
	JLabel JRollno,JName,JSection,JPhy,JMaths,JChem,JEng,JTotal,JPercentage,JGrade;
	JTextField tRollno,tName,tSection,tPhy,tMaths,tChem,tEng,tTotal,tPer,tGrade;
	JButton bSubmit,BCalculatePer,bCalTol,bCalGrade;

	
	public Student(String t) throws ClassNotFoundException, SQLException {
		super(t);
		cp=getContentPane();
		cp.setLayout(new GridLayout(11,2));
		
		//dao=new StudentDoa(); 
		JRollno=new JLabel("Roll no");
		tRollno=new JTextField();
		

		JSection=new JLabel("Section");
		tSection=new JTextField();

		JName=new JLabel("Name");
		tName=new JTextField();

		JPhy=new JLabel("Physics");
		tPhy=new JTextField();

		JMaths=new JLabel("Maths");
		tMaths=new JTextField();

		JChem=new JLabel("Chemistry");
		tChem=new JTextField();

		JEng=new JLabel("English");
		tEng=new JTextField();
		
		JTotal=new JLabel("Total");
		tTotal=new JTextField();
		
		JPercentage=new JLabel("Percentage");
		tPer=new JTextField();
		
		JGrade=new JLabel("Grade");
		tGrade=new JTextField();
		
		
		BCalculatePer=new JButton("Show");
		
		
		cp.add(JRollno);
		cp.add(tRollno);
		cp.add(JSection);
		cp.add(tSection);
		cp.add(JName);
		cp.add(tName);
		cp.add(JPhy);
		cp.add(tPhy);
		cp.add(JMaths);
		cp.add(tMaths);
		cp.add(JChem);
		cp.add(tChem);
		cp.add(JEng);
		cp.add(tEng);
		cp.add(JTotal);
		cp.add(tTotal);
		cp.add(JPercentage);
		cp.add(tPer);
		cp.add(JGrade);
		cp.add(tGrade);
		
		
		
		
		cp.add(BCalculatePer);
		
		BCalculatePer.addActionListener(this);
		setSize(500,500);
		setVisible(true);

		
	}
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
			new Student("Student");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==BCalculatePer)
		{
		int r=Integer.parseInt(tRollno.getText());
		try
		{
		 
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/studentDetails","root","root");
			
			
			

			
			
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				
			
				String q="select * from student where rollno=?";
				PreparedStatement ps=con.prepareStatement(q);
				ps.setInt(1, r);
				ResultSet rs=ps.executeQuery();
			
				if(rs.next()) {
					tSection.setText(rs.getString("section"));
					tName.setText(rs.getString("name"));
					tEng.setText(String .valueOf(rs.getDouble("eng_marks")));
					tMaths.setText(String .valueOf(rs.getDouble("maths_marks")));
					tPhy.setText(String .valueOf(rs.getDouble("phy_marks")));
					tChem.setText(String .valueOf(rs.getDouble("chem_marks")));
				
					tTotal.setText(""+rs.getDouble("total"));
					tPer.setText(""+rs.getDouble("per"));
					tGrade.setText(""+rs.getString("Grade"));
					
					
					
				}else {
					JOptionPane.showMessageDialog(this, "No data found");
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	}
	}

}
