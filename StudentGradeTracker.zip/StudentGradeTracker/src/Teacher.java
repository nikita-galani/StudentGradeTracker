import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.jar.Attributes.Name;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.Student;

public class Teacher extends JFrame implements ActionListener{
	Container cp;
	JLabel JRollno,JName,JSection,JPhy,JMaths,JChem,JEng,JTotal;
	JTextField tRollno,tName,tSection,tPhy,tMaths,tChem,tEng,tTotal;
	JButton bSubmit,BCalculatePer,bCalTol,bCalGrade;
	
	
	public Teacher(String t) throws ClassNotFoundException, SQLException
	{
		super(t);
		cp=getContentPane();
		cp.setLayout(new GridLayout(11,2));
	
		//dao=new StudentDoa();
		JRollno=new JLabel("Roll no");
		tRollno=new JTextField();
		

		JSection=new JLabel("Section");
		tSection=new JTextField();

		JName=new JLabel("Name");
		tName=new JTextField();

		JPhy=new JLabel("Physics");
		tPhy=new JTextField();

		JMaths=new JLabel("Maths");
		tMaths=new JTextField();

		JChem=new JLabel("Chemistry");
		tChem=new JTextField();

		JEng=new JLabel("English");
		tEng=new JTextField();
		
		JTotal=new JLabel("Total");
		tTotal=new JTextField();
		
		bCalTol=new JButton("Total");
		bSubmit=new JButton("Submit");
		
		
		cp.add(JRollno);
		cp.add(tRollno);
		cp.add(JSection);
		cp.add(tSection);
		cp.add(JName);
		cp.add(tName);
		cp.add(JPhy);
		cp.add(tPhy);
		cp.add(JMaths);
		cp.add(tMaths);
		cp.add(JChem);
		cp.add(tChem);
		cp.add(JEng);
		cp.add(tEng);
		cp.add(JTotal);
		cp.add(tTotal);
	
		cp.add(bSubmit);
		
		bSubmit.addActionListener(this);
		setSize(500,500);
		setVisible(true);
	}
	

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		new Teacher("Teacher");
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		
		int rollno=Integer.parseInt(tRollno.getText());
		String section=tSection.getText();
		String nm=tName.getText();
		double eng=Double.parseDouble(tEng.getText());
		double maths=Double.parseDouble(tMaths.getText());
		double phy=Double.parseDouble(tPhy.getText());
		double chem=Double.parseDouble(tChem.getText());
		
		
			if(e.getSource()==bSubmit) {
				
				double total=eng+maths+phy+chem;
				
				double per=(total/4)*100;
				
				String grade;
				if(per>=90) {
					grade="A+";
				}else if(per>=75)
				{
					grade="A";
				}else if(per>=60)
				{
					grade="B+";
				}else if(per>=50)	
				{
					grade ="B";
				}else if(per>=35) {
					grade ="C";
				}else {
					grade="F";
				}
				
				 String url="jdbc:mysql://localhost:3306/studentDetails";
				String user="root";
				 String pass="root";
				Connection con=null;
				PreparedStatement ps=null;
				String q;
				ResultSet rs=null;
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				
					con=DriverManager.getConnection(url,user,pass);
					
				q="insert into student values(?,?,?,?,?,?,?,?,?,?)";
				
				ps=con.prepareStatement(q);
				
				ps.setInt(1, rollno);
				ps.setString(2,section);
				ps.setString(3, nm);
				ps.setDouble(4, eng);
				ps.setDouble(5, maths);
				ps.setDouble(6, phy);
				ps.setDouble(7, chem);
				ps.setDouble(8, total);
				ps.setDouble(9, per);
				ps.setString(10, grade);
				
				
				int r=ps.executeUpdate();
				
				JOptionPane.showMessageDialog(this,"Data saved Successfully" );
				
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
				
				
								
			}
			if(e.getSource()==bSubmit) {
				
			}
	}
	

}
