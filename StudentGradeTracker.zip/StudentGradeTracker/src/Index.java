import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Index  extends JFrame implements ActionListener{

	Container cp;
	JButton bteacher,bstudent;
	
	public  Index(String t) {
		super(t);
		cp=getContentPane();
		cp.setLayout(null);
		
		bteacher=new JButton("Teacher");
		bstudent=new JButton("Student");
		
		bteacher.setBounds(45, 50,200,50);;
		bstudent.setBounds(260, 50,200,50);;
		
		cp.add(bteacher);
		cp.add(bstudent);
		
		bteacher.addActionListener(this);
		bstudent.addActionListener(this);
		//bstudent.setPreferredSize(new Dimension(100,100));
		setSize(500,500);
		setVisible(true);
	}
	public static void main(String[] args) {
			new Index("Student Grade");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
			try {
				if(e.getSource()==bteacher) {
				new Teacher("teacher");
				}
				if(e.getSource()==bstudent) {
					new Student("student");
				}
			}catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		
	}

}
